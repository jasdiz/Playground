#from flask import Flask  # Import Flask to allow us to create our app
#app = Flask(__name__)    # Create a new instance of the Flask class called "app"
#@app.route('/')          # The "@" decorator associates this route with the function immediately following
#def hello_world():
#    return 'Hello World!'  # Return the string 'Hello World!' as a response
#if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
#    app.run(debug=True)    # Run the app in debug mode.


from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def initial_render():
    return "go to http://localhost:5000/play to have it do something "

@app.route("/play")
def block_render():
    return render_template('index.html')

@app.route("/play/<number_of_boxes>")
def block_repeat(number_of_boxes):
    repeat = int(number_of_boxes)
    return render_template('index2.html', repeat=repeat)

@app.route("/play/<number_of_boxes>/<color_change>")
def box_color(number_of_boxes,color_change):
    repeat = (int(number_of_boxes))
    colorChange = color_change
    return render_template('index3.html', repeat = repeat, colorChange = colorChange )


if __name__ == "__main__":
    app.run(debug = True)


